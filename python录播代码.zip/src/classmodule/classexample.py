#!/usr/bin/env python
#coding=utf-8

class Person:

    def __init__(self):
        print "Init the class"


if __name__=="__main__":
    person1 = Person()
