#!/usr/bin/env python
#coding=utf-8

s='''my name is python
I love it
do you  know?
'''
print s