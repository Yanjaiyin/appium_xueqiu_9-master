#!/usr/bin/env python
#coding=utf-8

my_tuple=("python", 12, 2.3, 9.7)

tuple2 = (4,6)
print id(my_tuple)
print id(tuple2)
print id(my_tuple+tuple2)