#!/usr/bin/env python
#coding=utf-8

import logging

def testlog():
    logging.debug("this is another module")