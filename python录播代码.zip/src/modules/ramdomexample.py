#!/usr/bin/env python
# encoding: utf-8

import random

#print random.choice(["Jinhua","Jinhua1","Jinhua2","Jinhua4"])
for i in xrange(1,4):
    print random.choice(["Jinhua","Jinhua1","Jinhua2","Jinhua4"])
    print "$$"*20