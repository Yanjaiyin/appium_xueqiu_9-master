#!/usr/bin/env python
#coding=utf-8
import re

m = re.match('hello', 'hello world!')
print m.group()