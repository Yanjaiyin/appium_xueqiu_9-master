#!/usr/bin/env python
#coding=utf-8

a= raw_input(u"输入年龄：")
if int(a) >= 18:
    print "成年了"