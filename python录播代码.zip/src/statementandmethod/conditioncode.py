#!/usr/bin/env python
#coding=utf-8

age = 16
if age>=18:
    print "我年轻力壮"
else:
    print "我还是个孩子"