#!/usr/bin/env python
#coding=utf-8

age =int(raw_input("请输入年龄:"))
if age >= 18:
    print "我年轻力壮"
elif age >= 6 :
    print "我还是个孩子"
elif age >= 0:
    print "我是小宝宝"
else:
    print "我不是人"


