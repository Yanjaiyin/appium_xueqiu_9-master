#!/usr/bin/env python
#coding=utf-8

age= 18
sex="M"
if sex =="F":
    print "我是女孩子"
    if age >= 16:
        print "二八年华"
    elif age >= 13 :
        print "豆蔻年华"
    elif age >= 0:
        print "我是女宝宝"
elif sex=="M":
    print "我不是男孩子"
else:
    print "我是大猩猩"

