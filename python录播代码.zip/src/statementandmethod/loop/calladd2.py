#!/usr/bin/env python
#coding=utf-8

from method import add

print add.add_method(10,11)


import selenium

print selenium.__version__