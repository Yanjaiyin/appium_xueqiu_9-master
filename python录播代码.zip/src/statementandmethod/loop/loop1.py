#!/usr/bin/env python
#coding=utf-8

age = 0
while (age < 7):
   print '我还在 ', age," 岁，我不上学"
   age = age + 1

print "我要上学了"
