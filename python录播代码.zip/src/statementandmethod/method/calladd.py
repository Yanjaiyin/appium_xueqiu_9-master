#!/usr/bin/env python
#coding=utf-8

import add

#print add.add_method(100,11)
add.add_method("ab",1)