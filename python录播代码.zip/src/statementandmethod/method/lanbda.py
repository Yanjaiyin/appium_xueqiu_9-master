#!/usr/bin/env python
#coding=utf-8

add = lambda x, y: x+y
#print add(1,2)

def addme(x,y):
    return x+y

addme(1,2)