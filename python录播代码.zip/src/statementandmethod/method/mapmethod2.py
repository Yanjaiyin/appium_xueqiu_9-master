#!/usr/bin/env python
#coding=utf-8



def add(x, y):
    return x +y

x1 = (4,5,8)
y1 = [10,12,16]
print map(add, x1, y1)


